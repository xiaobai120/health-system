# 2022.10.24
# 界面设计
import PySide2
from PySide2.QtGui import QIcon
from PySide2.QtWidgets import QApplication, QWidget,QTextEdit,QTableWidget,QTableWidgetItem,QMessageBox
from PySide2.QtUiTools import QUiLoader
from PySide2.QtCore import QFile
from PySide2 import QtCore
import numpy
from check import *

class main_Widget():  # 界面类

    def __init__(self, path):  # 界面构造函数
        qfile_widget = QFile(path)  # ui文件路径
        qfile_widget.close()
        self.ui = QUiLoader().load(qfile_widget)  # 加载ui文件
        self.ui.window().setFixedSize(self.ui.window().width(), self.ui.window().height())  # 固定界面大小
        self.ui.window().setWindowIcon(QIcon('picture/09.jpg'))  # 设置窗口图片

#主窗口槽函数
def func_open_secwidget():
    mainwiget.ui.close()
    secwidget.ui.show()

def func_open_thirdwidget():
    mainwiget.ui.close()
    thirdwidget.ui.show()

def func_open_fourthwidget():
    mainwiget.ui.close()
    fourthwidget.ui.show()

def func_open_fiftwidget():
    mainwiget.ui.close()
    fifthwidget.ui.show()

def cloce_system():#退出系统.保存文件
    mainwiget.ui.close()
    file_save(data,'总表')

data=get_food_info('常见食物营养成分表.xlsx','总表')#表格数据

#食品信息查询界面槽函数
def Sfunc_backmainWidget():#返回主页面
    secwidget.ui.close()
    mainwiget.ui.show()
    secwidget.ui.textEdit_4.clear()#清空
    #secwidget.ui.textEdit_5.clear()

def Sfunc_findinf_bytype():#依据类型选择查找
    secwidget.ui.textEdit_4.clear()
    food_name=secwidget.ui.textEdit.toPlainText()#获取食品名
    choice=secwidget.ui.comboBox.currentText()
    str=''
    str=get_info_by_name(data,food_name,choice)
    secwidget.ui.textEdit_4.setPlainText(str)#显示

def Sfunc_findinf_byheat():#依据热量查找
    secwidget.ui.tableWidget.clear()
    min_heat=secwidget.ui.textEdit_min.toPlainText()#获取min
    max_heat = secwidget.ui.textEdit_max.toPlainText()#获取max
    flag,food_list=get_info_by_calories(data,min_heat,max_heat)
    secwidget.ui.tableWidget.setRowCount(len(food_list))#行数
    secwidget.ui.tableWidget.setColumnCount(8)#列数
    if flag==0:
        QMessageBox.critical(secwidget.ui,'错误','输入错误，请重新输入大于零的值！')
    elif flag==1:
        QMessageBox.information(secwidget.ui, '信息',  "不能找到此范围内的食物，请重新输入。")
    else:
        for i in range(len(food_list)):
            for j in range(len(food_list[i])):
                secwidget.ui.tableWidget.setItem(i, j, QTableWidgetItem(str(food_list[i][j])))#输出


def Sfunc_clear1():
    secwidget.ui.textEdit.clear()
    secwidget.ui.textEdit_4.clear()

def Sfunc_clear2():#清空
    secwidget.ui.tableWidget.setRowCount(0)
    secwidget.ui.tableWidget.setColumnCount(0)
    secwidget.ui.textEdit_min.clear()
    secwidget.ui.textEdit_max.clear()
    secwidget.ui.tableWidget.clear()
#____________________________________________________________________________________________________________

#食品信息编辑界面槽函数
def Tfunc_backmainWidget():#返回主页面
    thirdwidget.ui.close()
    thirdwidget.ui.textEdit.clear()
    thirdwidget.ui.textEdit_2.clear()
    mainwiget.ui.show()

def T_Sfunc_backlastWidget():#关闭子页面返回上级页面
    third_swidget.ui.close()
    third_swidget.ui.textEdit.clear()
    third_swidget.ui.textEdit_2.clear()
    third_swidget.ui.textEdit_3.clear()
    third_swidget.ui.textEdit_4.clear()
    third_swidget.ui.textEdit_5.clear()
    third_swidget.ui.textEdit_6.clear()
    third_swidget.ui.textEdit_7.clear()
    thirdwidget.ui.show()

def Tfunc_opera_select():#操作选择
    food_name=thirdwidget.ui.textEdit.toPlainText()
    opera=thirdwidget.ui.comboBox.currentText()
    #thirdwidget.ui.close()
    #print(food_name,opera)
    textEdit_list = []
    textEdit_list.append(third_swidget.ui.textEdit)
    textEdit_list.append(third_swidget.ui.textEdit_2)
    textEdit_list.append(third_swidget.ui.textEdit_3)
    textEdit_list.append(third_swidget.ui.textEdit_4)
    textEdit_list.append(third_swidget.ui.textEdit_5)
    textEdit_list.append(third_swidget.ui.textEdit_6)
    textEdit_list.append(third_swidget.ui.textEdit_7)
    if flag(data,food_name) & bool(opera == '修改'):
        third_swidget.ui.show()
        #thirdwidget.ui.setWindowModality(QtCore.Qt.AppliccationModal)
        third_swidget.ui.textEdit.setPlainText(food_name)
        prem_list=get_info_by_index(data,food_name)
        for i in range(1,7):
            print(prem_list[i-1])
            textEdit_list[i].setPlainText(prem_list[i-1])
    elif flag(data,food_name) & bool(opera == '删除'):
        delete_food(data,food_name)
        thirdwidget.ui.textEdit_2.setPlainText('删除成功')
    elif flag(data,food_name) & bool(opera == '增加'):
        thirdwidget.ui.textEdit_2.setPlainText('该食品已存在')
    elif ((not flag(data,food_name)) & bool(opera == '修改')) or ((not flag(data,food_name)) & bool(opera == '删除')):
        thirdwidget.ui.textEdit_2.setPlainText('该食品不存在')
    else:#不存在 增加
        third_swidget.ui.show()
        #third_swidget.ui.setWindowModality(QtCore.Qt.ApplicationModal)
        thirdwidget.ui.close()
        third_swidget.ui.textEdit.setPlainText(food_name)

def Tfunc_opera_process():#执行操作
    food_name=thirdwidget.ui.textEdit.toPlainText()
    opera=thirdwidget.ui.comboBox.currentText()
    food_kind=third_swidget.ui.comboBox.currentText()
    parameter_list = [food_kind,food_name]
    textEdit_list = []
    textEdit_list.append(third_swidget.ui.textEdit)
    textEdit_list.append(third_swidget.ui.textEdit_2)
    textEdit_list.append(third_swidget.ui.textEdit_3)
    textEdit_list.append(third_swidget.ui.textEdit_4)
    textEdit_list.append(third_swidget.ui.textEdit_5)
    textEdit_list.append(third_swidget.ui.textEdit_6)
    textEdit_list.append(third_swidget.ui.textEdit_7)
    for  i in range(1,7):
        parameter_list.append(textEdit_list[i].toPlainText())
    if opera=='增加':
        add_food(data,parameter_list)
    else:#修改
        modify_food(data,parameter_list)
    third_swidget.ui.close()
    for i in range(0,7):
        textEdit_list[i].clear()
    thirdwidget.ui.show()
    if opera=='增加':
        thirdwidget.ui.textEdit_2.setPlainText('添加成功')
    else:
        thirdwidget.ui.textEdit_2.setPlainText('修改成功')
#___________________________________________________________________________________________________________________

#食品信息统计界面槽函数
def Ffunc_backmainWidget():#返回主页面
    fourthwidget.ui.textEdit.clear()
    fourthwidget.ui.tableWidget.clear()
    fourthwidget.ui.close()
    mainwiget.ui.show()

def Ffunc_getinf_bychoice():# 按照热量、蛋白质、碳水化合物、脂肪含量中某个元素的顺序浏览
    choice_Element=fourthwidget.ui.comboBox.currentText()#元素选择
    choice_Way=fourthwidget.ui.comboBox_2.currentText()#排序方式选择
    list_1 = view_in_order(data, choice_Element, choice_Way)
    num_inf=fourthwidget.ui.textEdit.toPlainText()#获取行数
    if not num_inf.isdigit():#判断输入,错误提示
        QMessageBox.critical(fourthwidget.ui,'提示','请输入有效数字')
    else:
        if choice_Element=='ALL(不分排名)':
            fourthwidget.ui.tableWidget.setColumnCount(8)
            fourthwidget.ui.tableWidget.setRowCount(len(list_1))
            inf_list=list_1
        else:
            fourthwidget.ui.tableWidget.setColumnCount(2)
            fourthwidget.ui.tableWidget.setRowCount(int(num_inf))
            inf_list=list_1[:int(num_inf)+1]
        for i in range(len(inf_list)):
            for j in range(len(inf_list[i])):
                fourthwidget.ui.tableWidget.setItem(i, j, QTableWidgetItem(str(inf_list[i][j])))  # 输入方式

def Ffunc_clearinf():#清空输入输出
    fourthwidget.ui.tableWidget.setRowCount(0)
    fourthwidget.ui.tableWidget.setColumnCount(0)
    fourthwidget.ui.textEdit.clear()
    fourthwidget.ui.tableWidget.clear()

#______________________________________________________________________________________________________________________
#热量推荐界面槽函数
def Wfunc_backmainWidget():#返回主页面
    fifthwidget.ui.textEdit.clear()
    fifthwidget.ui.textEdit_2.clear()
    fifthwidget.ui.textEdit_3.clear()
    fifthwidget.ui.textEdit_4.clear()
    fifthwidget.ui.tableWidget.clear()
    fifthwidget.ui.close()
    mainwiget.ui.show()

def Wfunc_getpro_foodmenu():#获取三餐
    temp_height=fifthwidget.ui.textEdit.toPlainText()
    temp_weight=fifthwidget.ui.textEdit_2.toPlainText()
    temp_age=fifthwidget.ui.textEdit_3.toPlainText()
    if not (temp_height.isdigit()&temp_weight.isdigit()&temp_age.isdigit()):#判断输入
        QMessageBox.critical(fifthwidget.ui, '提示', '请输入有效数字')
    else:
        height = int(fifthwidget.ui.textEdit.toPlainText())  # 获取用户体重
        weight = int(fifthwidget.ui.textEdit_2.toPlainText())  # 获取用户身高
        age = int(fifthwidget.ui.textEdit_3.toPlainText())  # 获取用户年龄
        work_type = fifthwidget.ui.comboBox.currentText()  # 获取劳动类型
        if work_type == '轻度工作':
            workload = 1
        elif work_type == '中度工作':
            workload = 2
        else:
            workload = 3
        calories = daily_calories(height, weight, workload)  # 热量
        fifthwidget.ui.textEdit_4.setPlainText(str(calories))
        protein = daily_protein(weight, workload)  # 蛋白质
        fat = daily_fat(calories)  # 脂肪
        carbohydrate = daily_carbohydrate(calories, workload)  # 碳水
        calcium = daily_calcium(age)  # 钙
        iron = 25
        daily_needed = [protein, fat, carbohydrate, calories, calcium, iron]
        list_breakfast = breakfast_menu(daily_needed)
        list_lunch = lunch_menu(daily_needed)
        list_dinner = dinner_menu(daily_needed)
        list_all = list_breakfast + list_lunch + list_dinner#组装三餐列表
        fifthwidget.ui.tableWidget.setColumnCount(2)
        fifthwidget.ui.tableWidget.setRowCount(len(list_all))
        for i in range(len(list_all)):
            for j in range(len(list_all[i])):
                fifthwidget.ui.tableWidget.setItem(i, j, QTableWidgetItem(str(list_all[i][j])))  # 输入方式

def Wfunc_clear():#清空输出
    fifthwidget.ui.textEdit.clear()
    fifthwidget.ui.textEdit_2.clear()
    fifthwidget.ui.textEdit_3.clear()
    fifthwidget.ui.textEdit_4.clear()
    fifthwidget.ui.tableWidget.clear()
#_______________________________________________________________________________________________________________

if __name__ == '__main__':
    app = QApplication([])
    mainwiget = main_Widget(path='UI/mainWidget.ui')  # 创建主界面
    mainwiget.ui.setWindowFlags(PySide2.QtCore.Qt.WindowMinimizeButtonHint)
    mainwiget.ui.pushButton.clicked.connect(func_open_secwidget)  # 连接bt1与槽
    mainwiget.ui.pushButton_2.clicked.connect(func_open_thirdwidget)  # 连接bt2与槽
    mainwiget.ui.pushButton_3.clicked.connect(func_open_fourthwidget)  # 连接bt3与槽
    mainwiget.ui.pushButton_4.clicked.connect(func_open_fiftwidget)  # 连接bt4与槽
    mainwiget.ui.pushButton_5.clicked.connect(cloce_system)
    mainwiget.ui.show()  # 主页面显示

    #食品信息查询界面
    secwidget = main_Widget(path='UI/secWidget.ui')#界面创建
    #连接信号与槽
    secwidget.ui.s_pushButton_1.clicked.connect(Sfunc_backmainWidget)
    secwidget.ui.s_pushButton_2.clicked.connect(Sfunc_findinf_bytype)
    secwidget.ui.s_pushButton_3.clicked.connect(Sfunc_findinf_byheat)
    secwidget.ui.s_pushButton_clear1.clicked.connect(Sfunc_clear1)
    secwidget.ui.s_pushButton_clear2.clicked.connect(Sfunc_clear2)
    #_________________________________________________________________

    # 食品信息编辑界面
    thirdwidget = main_Widget(path='UI/thirdWidget.ui')#界面创建
    # 连接信号与槽
    thirdwidget.ui.t_pushButton_1.clicked.connect(Tfunc_backmainWidget)
    thirdwidget.ui.t_pushButton.clicked.connect(Tfunc_opera_select)
    # 食品信息操作子界面
    third_swidget=main_Widget(path='UI/third_sWidget.ui')#界面创建
    # 连接信号与槽
    third_swidget.ui.pushButton.clicked.connect(Tfunc_opera_process)
    third_swidget.ui.pushButton_2.clicked.connect(T_Sfunc_backlastWidget)

    #______________________________________________________________________

    # 食品信息统计界面
    fourthwidget=main_Widget(path='UI/fourthWidget.ui')#界面创建
    # 连接信号与槽
    fourthwidget.ui.f_pushButton_1.clicked.connect(Ffunc_backmainWidget)
    fourthwidget.ui.f_pushButton_2.clicked.connect(Ffunc_getinf_bychoice)
    fourthwidget.ui.f_pushButton_3.clicked.connect(Ffunc_clearinf)

    #_______________________________________________________________________

    # 热量推荐界面创建
    fifthwidget=main_Widget(path='Ui/fifthWidget.ui')#界面创建
    # 连接信号与槽
    fifthwidget.ui.w_pushButton_1.clicked.connect(Wfunc_backmainWidget)
    fifthwidget.ui.w_pushButton_2.clicked.connect(Wfunc_getpro_foodmenu)
    fifthwidget.ui.w_pushButton_3.clicked.connect(Wfunc_clear)

    app.exec_()

#注释看不懂 打给我 18059639328 我是个负责人的男人
