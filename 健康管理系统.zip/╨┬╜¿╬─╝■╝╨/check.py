import pandas as pd
import numpy as np
import math
from cvxopt import matrix, solvers
from openpyxl import load_workbook


# 读取常见食物营养成分表
def get_food_info(path, sheet):
    data = pd.read_excel(path, engine='openpyxl', sheet_name=sheet)
    return data


# 根据食物名称判断食物是否在表中
def flag(food_data, food_name):
    if food_name in food_data['食物名称'].unique():
        return True
    else:
        return False


# 根据食物名称查询索引
def get_index_by_name(food_data, food_name):
    idx = food_data[(food_data['食物名称'] == food_name)].index[0]
    return idx


# 按照食物名称以及食物某个营养成分查询食物信息
def get_info_by_name(food_data, food_name, choice):
    output = ''
    if flag(food_data, food_name):
        idx = get_index_by_name(food_data, food_name)
        if choice == 'ALL':
            output = '食物种类' + '\t' + '食物名称' + '\t' + '蛋白质（克）' + '\t' + '脂肪（克）' + '\t' + '碳水化合物（克）' + '\t' + '热量（千卡）' + '\t' + '钙（毫克）' + '\t' + '铁（毫克）' + '\n' + \
                     food_data['食物种类'][idx] + '\t' + food_name + '\t' + str(food_data['蛋白质（克）'][idx]) + '\t\t' + \
                     str(food_data['脂肪（克）'][idx]) + '\t\t' + str(food_data['碳水化合物（克）'][idx]) + '\t\t' + str(
                food_data['热量（千卡）'][idx]) + '\t\t' + \
                     str(food_data['钙（毫克）'][idx]) + '\t\t' + str(food_data['铁（毫克）'][idx])
        elif choice == '热量':
            output = '食物种类' + '\t' + '食物名称' + '\t' + '热量' + '\n' + str(
                food_data['食物种类'][idx]) + '\t' + food_name + '\t' + str(food_data['热量（千卡）'][idx])
        elif choice == '脂肪':
            output = '食物种类' + '\t' + '食物名称' + '\t' + '脂肪' + '\n' + str(
                food_data['食物种类'][idx]) + '\t' + food_name + '\t' + str(
                food_data['脂肪（克）'][idx])
        elif choice == '蛋白质':
            output = '食物种类' + '\t' + '食物名称' + '\t' + '蛋白质' + '\n' + str(
                food_data['食物种类'][idx]) + '\t' + food_name + '\t' + str(
                food_data['蛋白质（克）'][idx])
        else:
            output = '食物种类' + '\t' + '食物名称' + '\t' + '钙' + '\t' + '铁' + '\n' + str(
                food_data['食物种类'][idx]) + '\t' + food_name + '\t' + str(
                food_data['钙（毫克）'][idx]) + '\t' + str(food_data['铁（毫克）'][idx])
    else:
        output = "该食物不在此常见食物营养成分表中。"
    return output


# 根据索引返回食物信息
def get_info_by_index(food_data, food_name):
    idx = get_index_by_name(food_data, food_name)
    lst = [str(food_data['蛋白质（克）'][idx]), str(food_data['脂肪（克）'][idx]), str(food_data['碳水化合物（克）'][idx]),
           str(food_data['热量（千卡）'][idx]), str(food_data['钙（毫克）'][idx]), str(food_data['铁（毫克）'][idx])]
    return lst


# 按照食物热量范围查询食物信息
def get_info_by_calories(food_data, c1, c2):
    x1 = int(c1)
    x2 = int(c2)
    output = []
    flag = -1
    if (x1 < 0) | (x2 < 0):
        flag = 0 # "输入错误，请重新输入大于零的值！"
    elif (x2 < min(food_data['热量（千卡）'])) | (x2 > max(food_data['热量（千卡）'])):
        flag = 1 # "不能找到此范围内的食物，请重新输入。"
    else:
        output.append(['食物种类', '食物名称', '蛋白质（克）', '脂肪（克）', '碳水化合物（克）', '热量（千卡）', '钙（毫克）', '铁（毫克）'])
        idx = food_data[(food_data['热量（千卡）'] >= x1) & (food_data['热量（千卡）'] <= x2)].index.tolist()
        for i in idx:
            output.append([food_data['食物种类'][i], food_data['食物名称'][i], food_data['蛋白质（克）'][i],
                           food_data['脂肪（克）'][i], food_data['碳水化合物（克）'][i], food_data['热量（千卡）'][i],
                           food_data['钙（毫克）'][i], food_data['铁（毫克）'][i]])
    return flag,output


# 增加新食物信息
def add_food(food_data, parameter_list):
    idx = len(food_data)
    food_data.loc[idx, '食物种类'] = parameter_list[0]
    food_data.loc[idx, '食物名称'] = parameter_list[1]
    food_data.loc[idx, '蛋白质（克）'] = float(parameter_list[2])
    food_data.loc[idx, '脂肪（克）'] = float(parameter_list[3])
    food_data.loc[idx, '碳水化合物（克）'] = float(parameter_list[4])
    food_data.loc[idx, '热量（千卡）'] = float(parameter_list[5])
    food_data.loc[idx, '钙（毫克）'] = float(parameter_list[6])
    food_data.loc[idx, '铁（毫克）'] = float(parameter_list[7])
    return


# 修改某已有食物信息
def modify_food(food_data, parameter_list):
    idx = food_data[(food_data['食物名称'] == parameter_list[1])].index[0]
    food_data.loc[idx, '食物种类'] = parameter_list[0]
    food_data.loc[idx, '食物名称'] = parameter_list[1]
    food_data.loc[idx, '蛋白质（克）'] = float(parameter_list[2])
    food_data.loc[idx, '脂肪（克）'] = float(parameter_list[3])
    food_data.loc[idx, '碳水化合物（克）'] = float(parameter_list[4])
    food_data.loc[idx, '热量（千卡）'] = float(parameter_list[5])
    food_data.loc[idx, '钙（毫克）'] = float(parameter_list[6])
    food_data.loc[idx, '铁（毫克）'] = float(parameter_list[7])
    return


# 删除某已有食品全部信息
def delete_food(food_data, food_name):
    idx = food_data[(food_data['食物名称'] == food_name)].index[0]
    food_data.drop(idx, axis=0, inplace=True)
    food_data.reset_index(drop=True, inplace=True)
    return


# 按照热量、蛋白质、碳水化合物、脂肪含量中某个元素的顺序浏览
def view_in_order(food_data, food_composition, order):
    lst = []
    if food_composition == "ALL(不分排名)":
        lst.append(['食物种类', '食物名称', '蛋白质（克）', '脂肪（克）', '碳水化合物（克）', '热量（千卡）', '钙（毫克）', '铁（毫克）'])
        for i in range(len(food_data)):
            lst.append(food_data.iloc[i, :].values.tolist())
    else:
        lst = [['食物名称', food_composition]]
        if order == '从高到低':
            data = food_data.sort_values(by=[food_composition], ascending=False, inplace=False)
            for name in data['食物名称']:
                idx = get_index_by_name(data, name)
                lst.append([name, data[food_composition][idx]])
        else:
            data = food_data.sort_values(by=[food_composition], ascending=True, inplace=False)
            for name in data['食物名称']:
                idx = get_index_by_name(data, name)
                lst.append([name, data[food_composition][idx]])
    return lst


# 保存数据
def file_save(food_data,sheet):
    book = load_workbook('常见食物营养成分表.xlsx')
    with pd.ExcelWriter('常见食物营养成分表.xlsx') as writer:
        writer.book = book
        writer.sheets = {i.title: i for i in book.worksheets} # 指定sheet
        food_data.to_excel(writer, sheet_name=sheet, index=False)
    return


# 计算每日需要摄入的热量
def daily_calories(height, weight, workload):
    bmi = weight / math.pow(height, 2)
    if bmi < 20:
        if workload == 1:
            calories = 35 * weight
        elif workload == 2:
            calories = 40 * weight
        else:
            calories = 45 * weight
    elif bmi > 25:
        if workload == 1:
            calories = 25 * weight
        elif workload == 2:
            calories = 30 * weight
        else:
            calories = 35 * weight
    else:
        if workload == 1:
            calories = 30 * weight
        elif workload == 2:
            calories = 35 * weight
        else:
            calories = 40 * weight
    return calories


# 计算每日需要摄入的蛋白质
def daily_protein(weight, workload):
    if workload == 1:
        protein=0.8*weight
    elif workload == 2:
        protein = 1.2 * weight
    else:
        protein = 1.5 * weight
    return protein


# 计算每日需要摄入的脂肪
def daily_fat(calories):
    return calories * 0.25 / 9


# 计算每日需要摄入的碳水化合物
def daily_carbohydrate(calories, workload):
    if workload == 1:
        carbohydrate = 0.45 * calories
    elif workload == 2:
        carbohydrate = 0.55 * calories
    else:
        carbohydrate = 0.65 * calories
    return carbohydrate


# 计算每日需要摄入的钙
def daily_calcium(age):
    if age < 10:
        return "本系统不提供10岁以下儿童的饮食推荐。"
    if (age >= 10) & (age <= 19):
        calcium = 1200
    elif age >= 50:
        calcium = 1000
    else:
        calcium = 800
    return calcium


# 每日摄入的铁为8-45(mg)
# 热量分配：早餐30%，午餐40%，晚餐30%

# 早餐推荐
def breakfast_menu(daily_needed):
    # daily_needed为一个列表，里面为每日所需的营养物质：[protein,fat,carbohydrate,calories,calcium,iron]
    breakfast_needed = []
    for i in daily_needed:
        breakfast_needed.append(i * 0.3)  # 早餐占全天营养量的30%
    # 获取适合于早餐食用的食物名单
    breakfast_food_data = get_food_info('常见食物营养成分表.xlsx', '早餐')
    distribution = opt(breakfast_food_data, breakfast_needed)
    output = [['早餐', ' ']]
    for i in range(len(distribution)):
        if distribution[i] >= 10:
            output.append([breakfast_food_data.iloc[i, 1], str(int(distribution[i])) + '克'])
    return output


# 午餐推荐
def lunch_menu(daily_needed):
    # daily_needed为一个列表，里面为每日所需的营养物质：[protein,fat,carbohydrate,calories,calcium,iron]
    lunch_needed = []
    for i in daily_needed:
        lunch_needed.append(i * 0.4)  # 午餐占全天营养量的40%
    # 获取适合于早餐食用的食物名单
    lunch_food_data = get_food_info('常见食物营养成分表.xlsx', '午餐')
    distribution = opt(lunch_food_data, lunch_needed)
    output = [['午餐', ' ']]
    for i in range(len(distribution)):
        if distribution[i] >= 10:
            output.append([lunch_food_data.iloc[i, 1], str(int(distribution[i])) + '克'])
    return output


# 晚餐推荐
def dinner_menu(daily_needed):
    # daily_needed为一个列表，里面为每日所需的营养物质：[protein,fat,carbohydrate,calories,calcium,iron]
    dinner_needed = []
    for i in daily_needed:
        dinner_needed.append(i * 0.3)  # 晚餐占全天营养量的30%
    # 获取适合于早餐食用的食物名单
    dinner_food_data = get_food_info('常见食物营养成分表.xlsx', '晚餐')
    distribution = opt(dinner_food_data, dinner_needed)
    output = [['晚餐', ' ']]
    for i in range(len(distribution)):
        if distribution[i] >= 10:
            output.append([dinner_food_data.iloc[i, 1], str(int(distribution[i])) + '克'])
    return output


# 最优化函数
def opt(food_data, needed):
    protein = food_data['蛋白质（克）'].tolist()
    fat = food_data['脂肪（克）'].tolist()
    carbohydrate = food_data['碳水化合物（克）'].tolist()
    calories = food_data['热量（千卡）'].tolist()
    calcium = food_data['钙（毫克）'].tolist()
    iron = food_data['铁（毫克）'].tolist()

    # 准备cvxopt linear programming的相关系数
    length = len(food_data)
    c_temp = np.ones(length)  # 最小化函数的参数
    # h_temp为不等式约束函数右边的标量
    h_temp = []
    for i in range(len(needed)):
        h_temp.append(-needed[i])
    for i in range(length):
        protein[i] = float(protein[i])
        fat[i] = float(fat[i])
        carbohydrate[i] = float(carbohydrate[i])
        calories[i] = float(calories[i])
        calcium[i] = float(calcium[i])
        iron[i] = float(iron[i])
        h_temp.append(0.)
    # g_temp为不等式约束函数的系数
    g_temp = [[-p for p in protein], [-f for f in fat], [-c for c in carbohydrate],
              [-c for c in calories], [-c_ for c_ in calcium],  [-i for i in iron]]
    for i in range(length):
        temp_list = [0] * length
        temp_list[i] = -1
        g_temp.append(temp_list)

    c = matrix(c_temp)
    g = matrix(np.array(g_temp))
    h = matrix(np.array(h_temp))
    sol = solvers.lp(c, g, h)
    return 100*sol['x']
